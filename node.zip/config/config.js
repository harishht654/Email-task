var port=3000;
var mongodburl="mongodb://localhost:27017/email";


module.exports={
    port:port,
    mongodburl:mongodburl
}