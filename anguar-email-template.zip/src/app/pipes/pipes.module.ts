import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TruncatePipe } from './truncate.pipe';
import { SanitizeHtmlPipe } from './sanitize-html.pipe';



@NgModule({
  declarations: [TruncatePipe, SanitizeHtmlPipe],
  imports: [
    CommonModule
  ],
  exports:[
    TruncatePipe,
    SanitizeHtmlPipe
  ]
})
export class PipesModule { }
