import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './user-authentiction/login-page/login-page.component';
import { RegistrationComponent } from './user-authentiction/registration/registration.component';
import { ChangePasswordComponent } from './user-authentiction/change-password/change-password.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {SnackbarModule} from 'ngx-snackbar';
import { NgxEditorModule } from 'ngx-editor';
import { FormsModule } from '@angular/forms';
import { PipesModule } from './pipes/pipes.module';
import { DatePipe } from '@angular/common';
import { UiSwitchModule } from 'ngx-toggle-switch';

@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    RegistrationComponent,
    ChangePasswordComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    SnackbarModule.forRoot(),
    NgxEditorModule,
    PipesModule,
    UiSwitchModule 

  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
