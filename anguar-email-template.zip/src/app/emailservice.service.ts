import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SnackbarService } from 'ngx-snackbar';

@Injectable({
  providedIn: 'root'
})
export class EmailserviceService {
public domain="http://user:3000/"
  constructor(private http: HttpClient,private snackbarService: SnackbarService) { }
showSnackbar(message,time,action){
  this.snackbarService.add({
    msg: message,
    timeout: time,
    customClass:"snackbarClass",
    action: {
      text: action,
    },
  });
}

filesizeCalculator(bytes){
switch(true) { 
  case bytes>(1024*1024*1024*1024): { 
     return((bytes/(1024*1024*1024*1024)).toFixed(2)+" TB") 
     break; 
  } 
  case bytes>(1024*1024*1024): { 
     return((bytes/(1024*1024*1024)).toFixed(2)+" GB") 
     break; 
  } 
  case bytes>(1024*1024): { 
     return((bytes/(1024*1024)).toFixed(2)+" MB") 
     break; 
  } 
  case bytes>(1024): { 
     return((bytes/(1024)).toFixed(2)+" KB") 
     break; 
  } 
  default: { 
     return(bytes+" Bytes") 
     break; 
  } 
} 

if(bytes>(1024*1024*1024)){
  console.log(bytes/(1024*1024*1024)+"TB");
}else{

}

}

getlocalStorageData(data){  
  if (localStorage.getItem(data)) {
    return JSON.parse(localStorage.getItem(data))
  }else{
    return null
  }
}

}
