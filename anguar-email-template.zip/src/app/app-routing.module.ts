import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './user-authentiction/login-page/login-page.component';
import { RegistrationComponent } from './user-authentiction/registration/registration.component';
import { PagesModule } from './pages/pages.module';


const routes: Routes = [
  { path: '', component: LoginPageComponent },
  { path: 'login', component: LoginPageComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'pages', loadChildren:"./pages/pages.module#PagesModule" }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
