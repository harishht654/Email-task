import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { UserAuthService } from '../user-authentiction/user-auth.service';
import { EmailserviceService } from '../emailservice.service';
declare var $:any;
@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss']
})
export class PagesComponent implements OnInit {
  leftNavBar=false;
  fullScreenToggle=false;
  userData:any;
  public formGroup: FormGroup;

  constructor(private fb: FormBuilder,private auth:UserAuthService, private service: EmailserviceService,private router: Router) {
  
    this.formGroup = this.fb.group(
      {
        currentPassword: [null, [
          Validators.required,
          Validators.minLength(8)
        ]],
        password: [null, [
          Validators.required,
          Validators.minLength(8)
        ]]
      }
    )
setTimeout(() => {
  this.router.events.subscribe((event)=>{

  if(event['url'] && event['url']!="/pages/compose"){
      localStorage.removeItem("emailData");
    }
})  
}, 2000);

  }

 
  ngOnInit() {
    if(localStorage.userData){
      this.userData=JSON.parse(localStorage.userData)
    }else{
      this.router.navigate(["/"])
    }
  }

  toggleNav(){
    this.leftNavBar=!this.leftNavBar;
  }

  fullScreen() {
    this.fullScreenToggle=!this.fullScreenToggle;
    let elem = document.documentElement;
    let methodToBeInvoked = elem.requestFullscreen ||
      elem['webkitRequestFullScreen'] || elem['mozRequestFullscreen']
      ||
      elem['msRequestFullscreen'];
    if (methodToBeInvoked) methodToBeInvoked.call(elem);
}

closeFullscreen() {
  this.fullScreenToggle=!this.fullScreenToggle;
  if (document.exitFullscreen) {
		document.exitFullscreen();
	} else if (document['webkitExitFullscreen']) {
		document['webkitExitFullscreen()'];
	} else if (document['mozCancelFullScreen']) {
		document['mozCancelFullScreen()'];
	} else if (document['msExitFullscreen']) {
		document['msExitFullscreen()'];
	} else {
		console.log('Fullscreen API is not supported.');
  }
}
refresh() {
  window.location.reload();
}


changePassword(){
  var passData=this.formGroup.value;
  passData.email=this.userData.email;
  this.auth.changePassword(this.formGroup.value).subscribe((data) => {      
    if (data.msg) {
      this.service.showSnackbar(data.msg+", Login again", 2000, null);
      $('#changePassword').modal('toggle');
      setTimeout(() => {
        this.router.navigate(['/']);
      }, 500);
    } else {
      this.service.showSnackbar(data.error, 2000, null);
    }
  }, (error) => {
    this.service.showSnackbar("Something went wrong!!", null, null);

  }, () => {

  })
}
}
