import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { PagesService } from '../pages.service';
import { EmailserviceService } from 'src/app/emailservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common'

declare var $: any;
@Component({
  selector: 'app-compose-page',
  templateUrl: './compose-page.component.html',
  styleUrls: ['./compose-page.component.scss'],
  encapsulation: ViewEncapsulation.None,

})
export class ComposePageComponent implements OnInit {
  filesList = [];
  displayMail = false;
  bounceTimeClear=false;
  formData = [];
  attachments = [];
  sendMailData = {
    from: "",
    to: "",
    subject: "",
    body: "",
    attachments: [],
  }
  clearEnable = false;
  editorConfig = {
    "editable": true,
    "spellcheck": true,
    "height": "auto",
    "minHeight": "200px",
    "width": "auto",
    "minWidth": "0",
    "translate": "yes",
    "enableToolbar": true,
    "showToolbar": true,
    "placeholder": "Enter text here...",
    "imageEndPoint": "",
    "toolbar": [
      ["bold", "italic", "underline", "strikeThrough", "superscript", "subscript"],
      ["justifyLeft", "justifyCenter", "justifyRight", "justifyFull", "indent", "outdent"],
      ["cut", "copy", "delete", "removeFormat", "undo", "redo"],
      ["paragraph", "blockquote", "removeBlockquote", "horizontalLine", "orderedList", "unorderedList"]
    ]
  }
  
  bounceTime;
  userData;
  recivedObjectData = {};
  emailRegex = new RegExp("^(\s?[^\s,]+@[^\s,]+\.[^\s,]+\s?,)*(\s?[^\s,]+@[^\s,]+\.[^\s,]+)$", 'i');
  constructor(private pages: PagesService, private service: EmailserviceService,
    private router: Router, private activatedRoute: ActivatedRoute, public datepipe: DatePipe) {
    console.log(this.router.getCurrentNavigation().extras);
    if ("state" in this.router.getCurrentNavigation().extras) {
      if ('replyData' in this.router.getCurrentNavigation().extras.state) {
        this.recivedObjectData = this.router.getCurrentNavigation().extras.state['replyData'];
        var replyText = "On " + this.datepipe.transform(this.recivedObjectData['sentAt'], "EEE , LLL dd, yyyy 'at' hh:MM a") + " \< " + this.recivedObjectData['from'] + " \> wrote:";

        var body = '<br/> <br/> <br/><p>\
        <a class="collapseBtn" data-toggle="collapse" href=".sampleCollapseClassName" \
        role="button" aria-expanded="false" aria-controls="sampleCollapseClassName">...</a>\
      </p>\
      <div class="collapse sampleCollapseClassName" >\
        '+ replyText + '<br/> <div class="border-left">' + this.recivedObjectData['body'] + ' </div>\
      </div>';
        this.sendMailData.body = body;
        this.sendMailData['repliedTo'] = this.recivedObjectData['_id'];
        this.sendMailData.subject = "RE: " + this.recivedObjectData['subject'];
        this.sendMailData.to = this.recivedObjectData['from'];
      }
      if ('draftData' in this.router.getCurrentNavigation().extras.state) {

        this.recivedObjectData = this.router.getCurrentNavigation().extras.state['draftData'];
        localStorage.emailData=JSON.stringify(this.recivedObjectData);
        var to = "";
        this.recivedObjectData['to'].forEach((element, i) => {
          if (i == 0) {
            to = element.email;
          } else {
            to = to + "," + element.email;
          }
        });

        this.sendMailData.to = to;
        this.sendMailData.attachments = this.recivedObjectData['attachments'];
        this.sendMailData.body = this.recivedObjectData['body'];
        this.sendMailData.subject = this.recivedObjectData['subject'];
      }
      if ('forwardedData' in this.router.getCurrentNavigation().extras.state) {
        this.recivedObjectData = this.router.getCurrentNavigation().extras.state['forwardedData'];

        var to = "";
        this.recivedObjectData['to'].forEach((toData, i) => {
          if (i == 0)
            to = toData.email;
          else
            to = to + " , " + toData.email;
        });
        var replyText = "------Forwareded message------ <br\>From :" + this.recivedObjectData['from'] + "<br\>Date :" + this.datepipe.transform(this.recivedObjectData['sentAt'], "EEE , LLL dd, yyyy 'at' hh:MM a") + "<br\>Subject :" + this.recivedObjectData['subject'] + "<br\>To :" + to + "<br\>";


        var body = '<br/> <br/> <br/><p>\
        <a class="collapseBtn" data-toggle="collapse" href=".sampleCollapseClassName" \
        role="button" aria-expanded="false" aria-controls="sampleCollapseClassName">...</a>\
      </p>\
      <div class="collapse sampleCollapseClassName" >\
        '+ replyText + '<br/> <div class="border-left">' + this.recivedObjectData['body'] + ' </div>\
      </div>';
        this.sendMailData.body = body;
        this.sendMailData.subject = "Fwd: " + this.recivedObjectData['subject'];
        this.sendMailData.to = "";
      }


      this.displayMail = true;
    } else {
      this.displayMail = true
    }
  }

  ngOnInit() {
    if (localStorage.userData) {
      this.userData = JSON.parse(localStorage.userData)
    }
  }





  uploadChange(files) {
    if (files.length <= 3) {
      this.filesList = files;
      this.clearEnable = false;
      this.uploadFile(files, 0)
    } else {
      this.service.showSnackbar("Max. 3 attachments is acceptable", null, 'x');

    }
  }

  saveMail(noNotifications) {
    if (localStorage.emailData) {
      this.sendMailData['mailID'] = JSON.parse(localStorage.emailData)._id;
    }

    
    this.sendMailData.from = this.userData.email;
    this.sendMailData.attachments = this.attachments;
    var randomValue = "a" + Math.random().toString(36).substring(7) + new Date().getTime();
    this.sendMailData.body = this.sendMailData.body.replace(new RegExp("sampleCollapseClassName", "g"), randomValue);
    this.pages.save(this.sendMailData).subscribe((data) => {
      localStorage.emailData = JSON.stringify(data.data)
      this.sendMailData['mailID'] = JSON.parse(localStorage.emailData)._id;
      
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, 'x');
      return true;
    }, () => {
      if (noNotifications != true) {
        this.service.showSnackbar("Mail saved to draft", 1000, null);
      } else {
        clearTimeout(this.bounceTime);
        this.sendMail();
      }
    })
  }

  sendMail() {
    var regex = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9\-]+\.)+([a-zA-Z0-9\-\.]+)+([,]([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9\-]+\.)+([a-zA-Z0-9\-\.]+))*$/;

    console.log(regex.test(this.sendMailData.to))
    if (!regex.test(this.sendMailData.to)) {
      this.service.showSnackbar("Please specify at least one recipient.", null, 'x');
      return;
    } else {



      if (localStorage.emailData) {
        this.sendMailData['mailID'] = JSON.parse(localStorage.emailData)._id;
      }
      this.pages.send(this.sendMailData).subscribe((data) => {
        this.service.showSnackbar("Mail sent", 1000, null);
        this.router.navigate(["pages/inbox"]);
      }, (error) => {
        this.service.showSnackbar("Something went wrong!!", null, 'x');
      }, () => {

      })

    }
  }


  timedelayFunction() {
    clearTimeout(this.bounceTime);

    this.bounceTime = setTimeout(() => {
      this.saveMail(null);
    }, 3000);
  }

  clearAttachments() {
    $(".inputfile").val(null);
    console.log($(".inputfile"));
    this.attachments = [];
    this.filesList = [];
  }

  uploadFile(files, index) {
    if (index < files.length) {
      var formData = new FormData();
      formData.append("file", files[index], files[index].name)
      this.pages.fileUpload(formData).subscribe((data) => {
        console.log(data)
        if (data.status == "progress") {
          this.filesList[index].progress = data.message + "%";
        } else if (data.data) {
          this.attachments.push(data.data);
        }
      }, (error) => {
        this.service.showSnackbar("Something went wrong!!", null, 'x');
        this.filesList[index].completed = 2
        this.uploadFile(files, ++index);
      }, () => {
        this.filesList[index].completed = 1
        this.uploadFile(files, ++index);
      })
    } else {
      this.clearEnable = true;
      this.saveMail(null);
      return;
    }
  }
}
