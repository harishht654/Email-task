import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PagesComponent } from './pages.component';
import { Routes, RouterModule } from '@angular/router';
import { InboxPageComponent } from './inbox-page/inbox-page.component';
import { SentPageComponent } from './sent-page/sent-page.component';
import { DraftsPageComponent } from './drafts-page/drafts-page.component';
import { TrashPageComponent } from './trash-page/trash-page.component';
import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';
import { ComposePageComponent } from './compose-page/compose-page.component';
import { ViewMailComponent } from './view-mail/view-mail.component';
import { NgxEditorModule } from 'ngx-editor';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PipesModule } from '../pipes/pipes.module';
import { UiSwitchModule } from 'ngx-toggle-switch';

const routes: Routes = [
  { path: '', redirectTo: 'inbox'},
  { path: '', component: PagesComponent,children: [
    {path: '', redirectTo: 'inbox'},
    {path: 'dashboard', component: DashboardPageComponent},
    {path: 'compose', component: ComposePageComponent},
    {path: 'inbox', component: InboxPageComponent},
    {path: 'drafts', component: DraftsPageComponent},
    {path: 'sent', component: SentPageComponent},
    {path: 'trash', component: TrashPageComponent},
    {path: 'viewMail', component: ViewMailComponent},
  ]
  }
];

@NgModule({
  declarations: [
    PagesComponent, InboxPageComponent, SentPageComponent, DraftsPageComponent, TrashPageComponent, DashboardPageComponent, ComposePageComponent, ViewMailComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    NgxEditorModule,
    ReactiveFormsModule,
    FormsModule,
    PipesModule,
    UiSwitchModule
  ]
})
export class PagesModule { }
