import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PagesService } from '../pages.service';
import { EmailserviceService } from 'src/app/emailservice.service';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-view-mail',
  templateUrl: './view-mail.component.html',
  styleUrls: ['./view-mail.component.scss'],
  encapsulation: ViewEncapsulation.None,

})
export class ViewMailComponent implements OnInit {
  msgID;
  userData;
  mailData;
  constructor(private pages: PagesService, private service: EmailserviceService, private router: Router, private activatedRoute: ActivatedRoute) {
    if (this.activatedRoute.queryParams['value'].id) {
      this.msgID = this.activatedRoute.queryParams['value'].id;
      this.userData = this.service.getlocalStorageData('userData');
      this.getMails('inbox');
    }else if(this.activatedRoute.queryParams['value'].trash){
      this.msgID = this.activatedRoute.queryParams['value'].trash;
      this.userData = this.service.getlocalStorageData('userData');
      this.getMails('trash');
    } 
    else {
      this.router.navigate(['/pages'])
    }
    // if(activatedRoute.params['value'].id){
    //   this.msgID=activatedRoute.params['value'].id;
    // }else{
    //   this.router.navigate(['/pages/index'])
    // }
  }

  ngOnInit() {

  }

  getMails(from) {
    var obj = this.service.getlocalStorageData('userData');
    delete obj._id;
    obj['msgID'] = this.msgID;


    this.pages.viewMail(obj, from).subscribe((data) => {

      this.mailData = data[0];
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, null);

    }, () => {

    })
  }
  downloadFile(item) {
    
    this.pages.downloadfile(item).subscribe((response) => {
      FileSaver.saveAs(response, item.fileName);
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, null);

    }, () => {

    })
  }
}
