import { Component, OnInit } from '@angular/core';
import { PagesService } from '../pages.service';
import { EmailserviceService } from 'src/app/emailservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard-page',
  templateUrl: './dashboard-page.component.html',
  styleUrls: ['./dashboard-page.component.scss']
})
export class DashboardPageComponent implements OnInit {
  usersList = [];
  constructor(private pages: PagesService, private service: EmailserviceService, private router: Router) { }

  ngOnInit() {
    this.getallUsers();
  }


  getallUsers() {
    this.pages.getAllUsers().subscribe((data) => {
      console.log(data)
      this.usersList = data;
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, null);

    }, () => {

    })
  }
  onChange(event, item) {
    this.pages.updateStatus(event, item.email).subscribe((data) => {
      this.service.showSnackbar(data.msg, 2000, null);
      this.getallUsers()
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, null);

    }, () => {

    })
  }
  resetPassword( item) {
    this.pages.resetPassword( item.email).subscribe((data) => {
      this.service.showSnackbar(data.msg, 2000, null);
      this.getallUsers()
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, null);

    }, () => {

    })
  }
}
