import { Injectable } from '@angular/core';
import { HttpClient, HttpEventType, HttpHeaders } from '@angular/common/http';
import { EmailserviceService } from '../emailservice.service';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PagesService {


  constructor(private http: HttpClient, private service: EmailserviceService) { }
  domain = this.service.domain;
  inbox_url = this.domain + "mails/";
  save_url = this.domain + "mails/save";
  send_url = this.domain + "mails/send";
  upload_url = this.domain + "attachment/upload/";
  download_url = this.domain + "attachment/download";
  viewMail_url = this.domain + "mails/viewMail/";
  changeReadState_url = this.domain + "mails/changeReadState/";
  moveToTrash_url = this.domain + "mails/moveToTrash/";
  discardDraft_url = this.domain + "mails/discardDrafts";
  deleteFromTrash_url = this.domain + "mails/deleteFromTrash/";




  public inbox(from, data) {
    return this.http.get<any>(this.inbox_url + from + "/" + data.email);
  }
  public save(data) {
    return this.http.post<any>(this.save_url, data);
  }
  public send(data) {
     return this.http.post<any>(this.send_url, data);
  }
  public viewMail(data,from) {
     return this.http.post<any>(this.viewMail_url+from, data);
  }
  public changeReadState(email,state,data) {
     return this.http.post<any>(this.changeReadState_url+email+"/"+state, data);
  }
  public moveToTrash(from,email,data) {
     return this.http.post<any>(this.moveToTrash_url+from+"/"+email, data);
  }
  public discardDraft(data) {
     return this.http.post<any>(this.discardDraft_url, data);
  }
  public deleteFromTrash(from,data) {
     return this.http.post<any>(this.deleteFromTrash_url+from, data);
  }



  getAllusers_url=this.domain+ "admin/getAllUsers"
  updateStatus_url=this.domain+ "admin/update-status/"
  resetPassword_url=this.domain+ "admin/resetPassword/"

  public getAllUsers() {
     return this.http.get<any>(this.getAllusers_url);
  }
  public updateStatus(value,email) {
     return this.http.get<any>(this.updateStatus_url+email+"/"+value);
  }
  public resetPassword(email) {
     return this.http.get<any>(this.resetPassword_url+email);
  }
  public downloadfile(data): Observable<Blob> {

    // let headers = new HttpHeaders();


    // return this.http.post(this.download_url,data, {
    //   headers: headers,
    //   observe: 'response',
    //   responseType: 'text'
    // });
    return this.http
    .post(this.download_url,data, {
      responseType: "blob"
    });
     
    
  }


public testFileUpload(data){
  return this.http.post<any>(this.upload_url, data, {
    reportProgress: true,
    observe: 'events'
  });  
}

  public fileUpload(data) {
    var temp_url=this.upload_url+JSON.parse(localStorage.userData).email;
    console.log(temp_url)
    return this.http.post<any>(temp_url, data, {
      reportProgress: true,
      observe: 'events'
    }).pipe(map((event) => {

      switch (event.type) {

        case HttpEventType.UploadProgress:
          const progress = Math.round(100 * event.loaded / event.total);
          return { status: 'progress', message: progress };

        case HttpEventType.Response:
          return event.body;
        default:
          return `Unhandled event: ${event.type}`;
      }
    }))

  }

}
