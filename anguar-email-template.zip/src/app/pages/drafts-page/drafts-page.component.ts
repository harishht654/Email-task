import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { PagesService } from '../pages.service';
import { EmailserviceService } from 'src/app/emailservice.service';
import { Router } from '@angular/router';
declare var $:any;
@Component({
  selector: 'app-drafts-page',
  templateUrl: './drafts-page.component.html',
  styleUrls: ['./drafts-page.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DraftsPageComponent implements OnInit {
  inboxData = [];
  userData: any;
  selectedMails = [];

  constructor(private pages: PagesService, private service: EmailserviceService, private router: Router) {

  }

  ngOnInit() {
    this.displayAll();
  }


  displayAll() {
this.selectedMails=[];
    if (localStorage.userData) {
      this.userData = JSON.parse(localStorage.userData)
    }

    this.pages.inbox('drafts',this.userData).subscribe((data) => {

console.log(data)
      this.inboxData = data;
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, null);

    }, () => {

    })
  }
  unreadCheck() {
    this.inboxData.forEach(e1 => {
      e1.to.forEach(e2 => {
        if(e2.email==this.userData.email){
          e1.unread=e2.unread;
        }
      }); 
    });

  }
sampletext="sample textsample textsample textsample textsample textsample textsample text"
  contentReplace(content){
    return content.replace(/<[^>]*>/g, '');


  }
openMail(data){
  this.router.navigateByUrl('/pages/compose', { state: { draftData: data } });
}


discard(){
  if(this.selectedMails.length<=0){
    this.service.showSnackbar("Select mail to discard", 1000, null);

  }
  this.pages.discardDraft({ selectedMails: this.selectedMails }).subscribe((data) => {
    console.log(data)
    this.displayAll();
    this.selectedMails = [];

    this.service.showSnackbar(data.msg, 1000, null);

  }, (error) => {
    this.service.showSnackbar("Something went wrong!!", null, null);

  }, () => {

  })

}
checkBox(evt, mailID) {
  if (evt.target.checked) {
    this.selectedMails.push(mailID)
  } else {
    this.selectedMails.splice(this.selectedMails.indexOf(mailID), 1)
  }

}

getOnlyText(data){

  var html = $.parseHTML( data );
var text="";
  $.each( html, function( i, el ) {
   text=text.trim();
   text=text+" "+$(el).text();
  });

  return text;

}
}
