import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { EmailserviceService } from 'src/app/emailservice.service';
import { Router } from '@angular/router';
import { UserAuthService } from '../user-auth.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {
  public formGroup: FormGroup;
  constructor(private fb: FormBuilder,private auth:UserAuthService, private service: EmailserviceService,private router: Router) {
    this.formGroup = this.fb.group(
      {
        email: ['admin@domain.com', Validators.required],
        password: ['admin@123', [
          Validators.required,
          Validators.minLength(8)
        ]]
      }
    )
  }

  ngOnInit() {
    localStorage.removeItem("userData")
  }
  login() {
    this.auth.login(this.formGroup.value).subscribe((data) => {
      if (data.msg) {
        this.service.showSnackbar(data.msg, 2000, null);
        console.log(data)
        localStorage.userData=JSON.stringify(data.result)
        this.router.navigate(['./pages']);

      } else {
        this.service.showSnackbar("Invalid email or password", 2000, null);
      }
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, null);

    }, () => {

    })
  }
}
