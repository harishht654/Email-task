import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserAuthService } from '../user-auth.service';
import { EmailserviceService } from 'src/app/emailservice.service';
import { Router } from '@angular/router';
import { singleEmailValidator } from 'src/app/validators/emal-validator.validator';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
public mailExist=false
  public formGroup: FormGroup;
  constructor(private fb: FormBuilder,private auth:UserAuthService, private service: EmailserviceService,private router: Router) {
    this.formGroup = this.fb.group(
      {
        firstName: [null, [Validators.required,Validators.pattern("[a-zA-Z]+")]],
        lastName: [null, [Validators.required,Validators.pattern("[a-zA-Z]+")]],
        email: [null, [Validators.required,singleEmailValidator]],
        password: [null, [Validators.required, Validators.minLength(8)]]
      }
    )
  }


  ngOnInit() {
  }


  register() {
    this.auth.registration(this.formGroup.value).subscribe((data) => {
      if (data.msg) {
        this.service.showSnackbar(data.msg+", Please Login", 2000, null);
        localStorage.userData=JSON.stringify(data.result)
        this.router.navigate(['/']);
      } else {
        this.service.showSnackbar("Invalid email or password", 2000, null);
      }
    }, (error) => {
      this.service.showSnackbar("Something went wrong!!", null, null);

    }, () => {

    })
  }
  checkEmail() {
   this.mailExist=false;
    if(this.formGroup.controls.email.valid){
      this.auth.checkEmail(this.formGroup.value).subscribe((data) => {
        if(data.error){
          this.mailExist=true;
        }

      }, (error) => {
        this.service.showSnackbar("Something went wrong!!", null, null);
  
      }, () => {
  
      })
    }
    
  }
}
