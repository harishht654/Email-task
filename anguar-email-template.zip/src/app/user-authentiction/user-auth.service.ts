import { Injectable } from '@angular/core';
import { EmailserviceService } from '../emailservice.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  constructor(private http: HttpClient, private service: EmailserviceService) { }
  domain = this.service.domain;
  login_url = this.domain + "users/login"
  registration_url = this.domain + "users/create"
  checkEmail_url = this.domain + "users/email-check/"
  changePassword_url = this.domain + "users/change-password"
  public login(data) {
    return this.http.post<any>(this.login_url, data);
  }
  public changePassword(data) {
    return this.http.post<any>(this.changePassword_url, data);
  }
  public registration(data) {
    return this.http.post<any>(this.registration_url, data);
  }
  public checkEmail(data) {
    return this.http.get<any>(this.checkEmail_url+ data.email);
  }
}
