import { EmalValidator } from './emal-validator.validator';

describe('EmalValidator', () => {
  it('should create an instance', () => {
    expect(new EmalValidator()).toBeTruthy();
  });
});
