import { FormControl } from '@angular/forms';

// import { FormControl } from '@angular/forms';

//     export function singleEmailValidator(control: FormControl){
//          let EMAIL_REGEXP = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/i;
 
//          if (control.value != "" && (control.value.length <= 5 || !EMAIL_REGEXP.test(control.value))) {
//              return { "Please provide a valid email": true };
//          }
 
//          return null;
//      }
export const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

export function singleEmailValidator(control: FormControl): { [s: string]: boolean } {
    if (control.value && !control.value.match(EMAIL_REGEX)) {
      return {invalid: true};
    }
  }
  